my_age = 34;
my_name = "Luke";
my_comma= ',';

console.log("Hello " + my_name + my_comma + " I'm "+ my_age + " years old.");