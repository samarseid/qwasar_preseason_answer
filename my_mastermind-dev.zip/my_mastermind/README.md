# Welcome to My Mastermind
none

## Task
here it was necessary to create a game consisting of 9 secret pieces, and only 4 attempts

## Description
I solved the problem using my c knowledge

## Installation
Download it from github and open my_mastermind.c

## Usage
It works perfectly. Just do it!!, and give me tasks and challenges in this too
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
