# Welcome to My Moving Box Realtime
***

## Task
The problem was about moving the box by 1 pixel every 0.5 seconds

## Description
Using JS And setInterval() with 500 delay => 0.5 seconds

## Installation
Download it from github and open index.html

## Usage
It works perfectly. Just do it!!

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
