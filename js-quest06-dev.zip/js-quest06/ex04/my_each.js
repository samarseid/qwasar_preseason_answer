function my_each(param_1) {
    for (let i = 0; i < param_1.length; i++) {
        console.log(param_1[i]);
    }
}