function my_upcase(param_1) {
    return param_1.toUpperCase()
}