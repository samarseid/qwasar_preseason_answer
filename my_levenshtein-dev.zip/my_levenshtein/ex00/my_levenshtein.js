function my_levenshtein(a, b) {
    let index = 0;
    let total = 0;

    // Check if either of the strings is null or undefined
    if (a == null || b == null) {
        return 0;
    }

    // Check if the strings have different lengths
    if (a.length !== b.length) {
        return -1;
    }

    while (index < a.length && index < b.length) {
        if (a.charAt(index) !== b.charAt(index)) {
            total++;
        }
        index++;
    }

    return total;
}