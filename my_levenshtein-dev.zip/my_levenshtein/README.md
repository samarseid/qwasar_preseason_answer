# Welcome to My Levenshtein
***

## Task
the problem was to tell the difference between the words

## Description
I solved the problem by using the chartart function

## Installation
Download it from github and open index.html

## Usage
It works perfectly. Just do it!!
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
