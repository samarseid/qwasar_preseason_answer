const express=require("express")
const auth= require("basic-auth")
const app=express()

app.get("/", function(request, response){
    const samples=[
        "Ac-cent-tchu-ate the Positive",
        "Accidents Will Happen",
        "Adeste Fideles",
        "Ad-Lib Blues",
        "An Affair to Remember (Our Love Affair)",
        "After You've Gone",
        "Ain't She Sweet",
        "Ain't Cha Ever Comin' Back?",
        "Air For English Horn",
        "Alice Blue Gown",
        "All Alone",
        "All By Myself",
        "All I Do Is Dream of You",
        "All I Need is the Girl",
        "All My Tomorrows",
        "All of Me",
        "All of You",
        "All or Nothing at All",
        "All the Things You Are",
        "All the Way"
    ]
    const randomNumber=Math.floor(Math.random()*samples.length);
    response.send(samples[randomNumber]);
});
app.get("/birth_date",function(request, response) {
    response.send("December 12, 1915")
});
app.get("/birth_city",function(request, response) {
    response.send("Hoboken, New Jersey")
});
app.get("/wives",function(request, response) {
    response.send("Nancy Barbato, Ava Gardner, Mia Farrow, Barbara Marx")
});
app.get("/picture",function(request, response) {
    response.redirect("https://en.wikipedia.org/wiki/Frank_Sinatra#/media/File:Frank_Sinatra2,_Pal_Joey.jpg")
});
app.get("/public",function(request, response) {
    response.send("Everybody can see this page")
});
app.get("/protected",function(request, response){
    const user=auth(request);
    if(user===undefined||user["name"]!='admin'||user['pass']!='admin'){
    response.statusCode=401;
    response.setHeader("WWW-Authenticate","Basic realm='MyRealmName'");
    response.send("Not authorized");}else{
        response.send("Welcome, authenticated client")
    }
})
app.listen(8080, function(){
    console.log("Server ishga tushdi")
});