#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
int main(int argc, char ** argv)
{
    int fd, ch;
    for(int a=1; a < argc; a++)
    {
        fd = open(argv[a], O_RDONLY);
        if(fd < 0)
        {
            perror(argv[a]);
            continue;
        }
        while(read(fd, &ch,1) == 1)
        {
            write(STDOUT_FILENO, &ch,1);
        }
    close(fd);
    }
}