# Welcome to My Cat
***

## Task
What is the problem? And where is the challenge?

## Description
How have you solved the problem?

## Installation
How to install your project? npm install? make? make re?

## Usage
How does it work?
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
