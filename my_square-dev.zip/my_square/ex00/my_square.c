#include <stdio.h>
#include <stdlib.h>
int main(int argc, char **argv){
    if (argc != 3)
    {
return 0;

    }
    int a = atoi(argv[1]);
    int b = atoi(argv[2]);
    for(int i=1; i<=a; i++)
    {
 for(int j=1;j<=b;j++)
{
if ((j==1&&i==1)||(i==a&&j==b)||(i==1&&j==b)||(i==a&&j==1))
{
    printf("o");

}
else if (i==1||i==a)
  {
 printf("-");
 }
else if(j==1||j==b)
  {
  printf("|");

 }
 else
 {
  printf(" ");
            }}
      printf("\n");
}
  return 0;
}