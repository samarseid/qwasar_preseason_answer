function my_count_on_it(param_1) {
let array = []
for (let i = 0; i < param_1.length; i++) { 
    array.push(param_1[i].length)
}
return array
}