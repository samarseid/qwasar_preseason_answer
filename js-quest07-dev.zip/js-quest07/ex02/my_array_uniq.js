function my_array_uniq(param_1) {
    let uniqueArray = [];
  
    for (let i = 0; i < param_1.length; i++) {
      if (uniqueArray.indexOf(param_1[i]) === -1) {
        uniqueArray.push(param_1[i]);
      }
    }
  
    return uniqueArray;
  }
  
  