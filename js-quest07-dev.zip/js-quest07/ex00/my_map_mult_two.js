function my_map_mult_two(param_1) {
    let newArray = [];

    for (let i = 0; i < param_1.length; i++) {
        newArray.push(param_1[i]*2)
    } 
    return newArray
}