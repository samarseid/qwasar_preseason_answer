#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* my_strcpy(char* param_1, char* param_2)
{
int b= strlen(param_2)-1;
for (int j=0; j<=b; j++){
param_1[j]=param_2[j];
}
return param_1;
}