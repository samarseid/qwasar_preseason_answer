#include <stdio.h>
#include <string.h>

char* reverse_string(char* param_1)
{
    int length = strlen(param_1);
    for (int i = 0; i < length / 2; i++) {
        char temp = param_1[i];
        param_1[i] = param_1[length - 1 - i];
        param_1[length - 1 - i] = temp;
    }
    return param_1;
}