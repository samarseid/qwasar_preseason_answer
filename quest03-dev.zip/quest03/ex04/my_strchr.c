#include <stdio.h>
char* my_strchr(char* param_1, char param_2)
{
while ( *param_1 && *param_1 != param_2 ) ++param_1;
return ( char * )( param_2 == *param_1 ? param_1 : 0 ); 
}