#include <stdio.h>
#include <string.h>
#define MAX_CHARS 256
void salom_my_ngram(const char* str) {
    int a[MAX_CHARS] = {0};
  int i;
    for (i =0;str[i] !='\0'; i++) {
    a[(unsigned char)str[i]]++;
    }
for (i= 0;i<MAX_CHARS; i++) {
    if (a[i]>0) {
printf("%c:%d\n", (char)i, a[i]);
  }
 }
}

int main(int argc, char* argv[]) {
 if (argc < 2) {
   printf("%s\n", argv[0]);
        return 1;}

 for (int i = 1; i < argc; i++) {
 salom_my_ngram(argv[i]);
   }

    return 0;
}