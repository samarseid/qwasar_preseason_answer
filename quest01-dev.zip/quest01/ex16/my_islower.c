#include <stdio.h>

int my_islower(char param_1) {
  if (param_1 >= 'a' && param_1 <= 'z') {
    return 1; // Character is a lowercase letter
  } else {
    return 0; // Character is not a lowercase letter
  }
}
