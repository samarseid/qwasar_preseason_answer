#include <stdio.h>

int my_isdigit(char param_1) {
  if (param_1 >= '0' && param_1 <= '9') {
    return 1; // Character is a digit
  } else {
    return 0; // Character is not a digit
  }
}

