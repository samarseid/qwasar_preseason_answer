#include <stdio.h>

int main() {
  int my_index = 0;

  // replace this comment with an increment
  my_index++;
  printf("%d\n", my_index);
  // replace this comment with an decrement
  // replace this comment with an decrement
  my_index--;
  my_index--;
  printf("%d\n", my_index);
  // replace this comment with an increment
  // replace this comment with an increment
  // replace this comment with an increment
  my_index++;
  my_index++;
  my_index++;
  printf("%d\n", my_index);
  return 0;
}