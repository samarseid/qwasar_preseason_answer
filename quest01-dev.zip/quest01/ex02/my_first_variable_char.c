#include <stdio.h>

int main() {
  int my_letter = 'c';

  printf("%c\n", my_letter);
  return 0;
}