#include <stdio.h>

int my_abs(int param_1) {
  if (param_1 < 0) {
    return -param_1; // Return the negation of the negative number to make it positive
  } else {
    return param_1; // Return the positive number as is
  }
}
