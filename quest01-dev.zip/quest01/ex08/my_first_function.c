#include <stdio.h>

// Function definition
void my_first_function() {
  printf("my_first_function\n");
}

int main() {
  // Function call
  my_first_function();

  return 0;
}
