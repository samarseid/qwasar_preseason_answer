#include <stdio.h>

int my_isalpha(char param_1) {
  if ((param_1 >= 'a' && param_1 <= 'z') || (param_1 >= 'A' && param_1 <= 'Z')) {
    return 1; // Character is a letter
  } else {
    return 0; // Character is not a letter
  }
}
