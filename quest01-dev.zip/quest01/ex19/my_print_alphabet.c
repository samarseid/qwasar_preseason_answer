#include <stdio.h>

void my_print_alphabet() {
    char letter = 'a';

    while (letter <= 'z') {
        putchar(letter);
        letter++;
    }

    putchar('\n');
}
