#include <stdio.h>

// Function definition
int my_get_seven() {
  return 7;
}

int main() {
  printf("%d\n", my_get_seven());
  return 0;
}
