#include <stdio.h>

int main() {
  int nbr = 10;

  if (nbr > 20) {
    printf("nbr is greater than 20\n");
  }
  else {
    printf("nbr is less than 20\n");
  }
  return 0;
}