#include <stdio.h>

int main() {
  int index = 0;

  while (index < 100) {
    printf("I want to code\n");
    index++;
  }
  return 0;
}