#include <stdio.h>

int main() {
  int person_age = 34;

  printf("%d\n", person_age);
  return 0;
}