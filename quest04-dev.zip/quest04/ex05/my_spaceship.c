#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<stdlib.h>
char* my_spaceship(char* param_1){
    int x = 0;
    int y = 0;
    int index;
    char* side = "up";
    char* list_side[4] = {"up","right","down","left"};
    for(int i=0;i<strlen(param_1);i++){
        char el = param_1[i];
        if(el == 'R'){
            if(list_side[0] == side) index = 1;
            if(list_side[1] == side) index = 2;
            if(list_side[2] == side) index = 3;
            if(list_side[3] == side) index = 0;
            side = list_side[index];
        }
        if(el == 'L'){
            if(list_side[0] == side) index = 3;
            if(list_side[1] == side) index = 0;
            if(list_side[2] == side) index = 1;
            if(list_side[3] == side) index = 2;
            side = list_side[index];
        }
        if(el == 'A'){
            if(side == "up")    y--;
            if(side == "down")  y++;
            if(side == "left")  x--;
            if(side == "right") x++;
            }
        }
        char* res = malloc(100);
        sprintf(res,"{x: %d, y: %d, direction: '%s'}",x,y,side);
        return res;
}