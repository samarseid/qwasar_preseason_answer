#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char* my_strdup(char* param_1)
{
 return param_1;
}