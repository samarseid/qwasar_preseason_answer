#include <stdio.h>
void my_initializer(int*param){
    *param=0;
}