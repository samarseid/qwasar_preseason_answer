#include <stdio.h>

int my_string_index(char* param_1, char param_2)
{
    int position = -1;  // Initialize position to -1 (not found)

    for (int i = 0; param_1[i] != '\0'; i++) {
        if (param_1[i] == param_2) {
            position = i;  // Update position when a match is found
            break;         // Exit the loop as we found the first occurrence
        }
    }

    return position;
}