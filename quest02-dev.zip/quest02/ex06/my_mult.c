int my_mult(int param_1, int param_2)
{
    int result = param_1 * param_2;
    return result;
}
