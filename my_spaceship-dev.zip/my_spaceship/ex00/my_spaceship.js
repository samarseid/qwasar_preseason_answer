function my_spaceship(flight_path) {
    var direction, result, x, y;
    x = 0;
    y = 0;
    direction = "up";
  
    for (var c, _pj_c = 0, _pj_a = flight_path, _pj_b = _pj_a.length; _pj_c < _pj_b; _pj_c += 1) {
      c = _pj_a[_pj_c];
  
      if (c === "R") {
        if (direction === "up") {
          direction = "right";
        } else {
          if (direction === "right") {
            direction = "down";
          } else {
            if (direction === "down") {
              direction = "left";
            } else {
              if (direction === "left") {
                direction = "up";
              }
            }
          }
        }
      } else {
        if (c === "L") {
          if (direction === "up") {
            direction = "left";
          } else {
            if (direction === "right") {
              direction = "up";
            } else {
              if (direction === "down") {
                direction = "right";
              } else {
                if (direction === "left") {
                  direction = "down";
                }
              }
            }
          }
        } else {
          if (c === "A") {
            if (direction === "up") {
              y -= 1;
            } else {
              if (direction === "right") {
                x += 1;
              } else {
                if (direction === "down") {
                  y += 1;
                } else {
                  if (direction === "left") {
                    x -= 1;
                  }
                }
              }
            }
          }
        }
      }
    }
  
    result = "{x: " + x.toString() + ", y: " + y.toString() + ", direction: '" + direction + "'}";
    return result;
  }
  