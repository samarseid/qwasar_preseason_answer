# Welcome to My Spaceship
***

## Task
the problem was to find the location of the missile through a coordinate point

## Description
I learned the problem through a function I learned in JS

## Installation
Download it from github and open my_spaceship.js

## Usage
It works perfectly. Just do it!!
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px' /></span>
