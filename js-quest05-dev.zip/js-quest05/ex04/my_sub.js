function my_sub(param1, param2) {
    return(param1 - param2)
}