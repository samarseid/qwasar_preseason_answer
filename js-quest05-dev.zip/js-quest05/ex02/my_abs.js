function my_abs(parm_1) {
    if (parm_1 < 0) {
        return Math.abs(param_1)
    } else {
        return parm_1
    }
}